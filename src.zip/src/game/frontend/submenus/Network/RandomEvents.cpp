#include "RandomEvents.hpp"
#include "core/backend/FiberPool.hpp"
#include "core/backend/ScriptMgr.hpp"
#include "core/frontend/Notifications.hpp"
#include "game/backend/Self.hpp"
#include "game/backend/Tunables.hpp"
#include "game/backend/ScriptPatches.hpp"
#include "game/gta/data/RandomEvents.hpp"
#include "game/gta/Scripts.hpp"
#include "game/gta/ScriptFunction.hpp"
#include "types/script/globals/GPBD_FM_2.hpp"
#include "types/script/globals/GSBD_RandomEvents.hpp"
#include "types/script/locals/FMRandomEvents.hpp"
#include "types/script/ScriptEvent.hpp"
#include "types/script/GtaThread.hpp"
#include "types/script/CGameScriptHandlerNetComponent.hpp"
#include "types/network/CNetGamePlayer.hpp"

namespace YimMenu::Submenus
{
	enum eRandomEvent
	{
		DRUG_VEHICLE,
		MOVIE_PROPS,
		GOLDEN_GUN,
		VEHICLE_LIST,
		SLASHER,
		PHANTOM_CAR,
		SIGHTSEEING,
		SMUGGLER_TRAIL,
		CERBERUS,
		SMUGGLER_PLANE,
		CRIME_SCENE,
		METAL_DETECTOR,
		CONVOY,
		ROBBERY,
		XMAS_MUGGER,
		BANK_SHOOTOUT,
		ARMOURED_TRUCK,
		POSSESSED_ANIMALS,
		GHOSTHUNT,
		XMAS_TRUCK,
		COMMUNITY_OUTREACH,
		GETAWAY_DRIVER,
		SURVIVAL_GROUPING,
		VALENTINE_CHEATER,

		MAX_EVENTS
	};

	static std::vector<ScriptPatch> sendUpdateRECoordsTSECooldownPatches{};
	static GPBD_FM_2* GPBDFM2 = nullptr;
	static GSBD_RandomEvents* GSBDRandomEvents = nullptr;
	static RANDOM_EVENTS_FREEMODE_DATA* FMRandomEvents = nullptr;
	static eRandomEvent selectedEvent = DRUG_VEHICLE;
	static int selectedSubvariation = 0;
	static int numSubvariations = 29;
	static int setCooldown = 1800000;
	static int setAvailability = 900000;
	static bool applyInMinutes = false;

	static std::string GetEventStateString()
	{
		switch (GSBDRandomEvents->EventData[selectedEvent].State)
		{
		case eRandomEventState::INACTIVE:
			return "未激活 - 将在 " + GSBDRandomEvents->EventData[selectedEvent].TimerState.GetRemainingTimeStr(FMRandomEvents->EventData[selectedEvent].InactiveTime) + " 后启动";
		case eRandomEventState::AVAILABLE:
			return "可用 - 将在 " + GSBDRandomEvents->EventData[selectedEvent].TimerState.GetRemainingTimeStr(FMRandomEvents->EventData[selectedEvent].AvailableTime) + " 后停用";
		case eRandomEventState::ACTIVE:
			return "进行中";
		case eRandomEventState::CLEANUP:
			return "清理中";
		}

		return "无";
	}

	static int GetNumLocallyActiveEvents()
	{
		int numEvents{};

		for (int event = DRUG_VEHICLE; event < MAX_EVENTS; event++)
		{
			if (GPBDFM2->Entries[Self::GetPlayer().GetId()].RandomEventsClientData.EventData[event].State != eRandomEventClientState::INACTIVE)
				numEvents++;
		}

		return numEvents;
	}

	static void ResetEventTunables(eRandomEvent event)
	{
		if (event == ARMOURED_TRUCK) // It doesn't have tunables
		{
			setCooldown = *ScriptGlobal(262145).At(33808).As<int*>();
			setAvailability = *ScriptGlobal(262145).At(33809).As<int*>();
		}
		else
		{
			// Phantom Car's cooldown is actually 2147483647ms if STANDARDTARGETTINGTIME is not enabled
			if (auto tunable = Tunables::GetTunable(randomEventCooldowns[event]))
				setCooldown = *tunable->As<int*>();
			if (auto tunable = Tunables::GetTunable(randomEventAvailabilities[event]))
				setAvailability = *tunable->As<int*>();
		}
	}

	static void OnComboChange()
	{
		static ScriptFunction getNumFMMCVariations("freemode"_J, ScriptPointer("GetNumFMMCVariations", "5D ? ? ? 01 72 02 39 04").Add(1).Rip());
		numSubvariations = getNumFMMCVariations.Call<int>(FMRandomEvents->MissionData.FMMCData[selectedEvent].FMMCType, 0) - 1;
		selectedSubvariation = 0;
		ResetEventTunables(selectedEvent);
	}

	static void KillActiveEvent()
	{
		if (auto eventThread = Scripts::FindScriptThread(randomEventScripts[static_cast<int>(selectedEvent)]))
		{
			if (auto NetComponent = reinterpret_cast<GtaThread*>(eventThread)->m_NetComponent)
			{
				if (NetComponent->IsLocalPlayerHost())
				{
					ScriptFunction setFMContentScriptServerState(randomEventScripts[static_cast<int>(selectedEvent)], ScriptPointer("SetFMContentScriptServerState", "5D ? ? ? 55 2E 00 5D").Add(1).Rip());
					setFMContentScriptServerState.Call<void>(3);
				}
				else
				{
					ScriptFunction setFMContentScriptClientState(randomEventScripts[static_cast<int>(selectedEvent)], ScriptPointer("SetFMContentScriptClientState", "5D ? ? ? 55 08 00 74").Add(1).Rip());
					setFMContentScriptClientState.Call<void>(3);
				}
			}
		}
		else
		{
			Notifications::Show("随机事件", "事件脚本未激活。你是参与者吗？", NotificationType::Error);
		}
	}

	std::shared_ptr<Category> BuildRandomEventsMenu()
	{
		if (sendUpdateRECoordsTSECooldownPatches.empty())
		{
			for (int event = DRUG_VEHICLE; event < MAX_EVENTS; event++)
			{
				// TODO: this can crash the game
				sendUpdateRECoordsTSECooldownPatches.push_back(ScriptPatches::AddPatch(randomEventScripts[event], ScriptPointer("SendUpdateRECoordsTSECooldownPatch", "43 88 13 2E 00 01"), {0x71, 0x00, 0x00}));
			}
		}

		for (auto& patch : sendUpdateRECoordsTSECooldownPatches)
			patch->Enable();

		auto menu = std::make_shared<Category>("随机事件");

		menu->AddItem(std::make_unique<ImGuiItem>([] {
			GPBDFM2 = GPBD_FM_2::Get();
			GSBDRandomEvents = GSBD_RandomEvents::Get();
			if (!GPBDFM2 || !GSBDRandomEvents)
				return ImGui::Text("自由模式全局数据块未加载。");

			if (GPBDFM2->Entries[Self::GetPlayer().GetId()].RandomEventsClientData.InitState != eRandomEventClientInitState::INITIALIZED)
				return ImGui::Text("随机事件尚未初始化。");

			if (auto freemode = Scripts::FindScriptThread("freemode"_J))
			{
				FMRandomEvents = RANDOM_EVENTS_FREEMODE_DATA::Get(freemode);
				if (!FMRandomEvents)
					return ImGui::Text("自由模式栈无效。");
			}
			else
			{
				return ImGui::Text("自由模式未运行。");
			}

			if (ImGui::BeginCombo("选择事件", randomEventNames[selectedEvent]))
			{
				for (int event = DRUG_VEHICLE; event < MAX_EVENTS; event++)
				{
					switch (GSBDRandomEvents->EventData[event].State)
					{
					case eRandomEventState::INACTIVE:
					case eRandomEventState::CLEANUP:
						ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 0.0f, 0.0f, 1.0f));
						break;
					case eRandomEventState::AVAILABLE:
						ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 1.0f, 1.0f, 1.0f));
						break;
					case eRandomEventState::ACTIVE:
						ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.0f, 1.0f, 0.0f, 1.0f));
						break;
					}

					if (ImGui::Selectable(randomEventNames[event], event == selectedEvent))
					{
						FiberPool::Push([event] {
							selectedEvent = (eRandomEvent)event;
							OnComboChange();
						});
					}

					ImGui::PopStyleColor();
				}

				ImGui::EndCombo();
			}

			if (ImGui::InputInt(std::format("选择地点（0-{}）", numSubvariations).c_str(), &selectedSubvariation))
			{
				selectedSubvariation = std::clamp(selectedSubvariation, 0, numSubvariations);
			}

			int numActiveEvents = GetNumLocallyActiveEvents();
			static Tunable maxEventsTune{"FMREMAXACTIVATEDEVENTS"_J};
			int maxActiveEvents = maxEventsTune.IsReady() ? maxEventsTune.Get<int>() : 0;
			if (numActiveEvents >= maxActiveEvents)
				ImGui::TextColored(ImVec4(1.0f, 0.0f, 0.0f, 1.0f), "进行中的事件：%d/%d", numActiveEvents, maxActiveEvents);
			else
				ImGui::Text("进行中的事件：%d/%d", numActiveEvents, maxActiveEvents);

			if (ImGui::Button("启动事件"))
			{
				FiberPool::Push([] {
					if (GSBDRandomEvents->EventData[selectedEvent].State != eRandomEventState::ACTIVE)
					{
						SCRIPT_EVENT_REQUEST_RANDOM_EVENT eventData;
						eventData.FMMCType = FMRandomEvents->MissionData.FMMCData[selectedEvent].FMMCType;
						eventData.Subvariation = selectedSubvariation;
						eventData.PlayersToSend = 1; // Set FORCE_LAUNCH bit of all players
						eventData.Send();
						ScriptMgr::Yield(100ms);
						if (GSBDRandomEvents->EventData[selectedEvent].State == eRandomEventState::INACTIVE)
						{
							Notifications::Show("随机事件", "启动事件失败。你是自由模式主机吗？", NotificationType::Error);
						}
					}
					else
					{
						Notifications::Show("随机事件", "事件已经处于激活状态。", NotificationType::Error);
					}
				});
			}
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip("需要成为自由模式脚本主机。");

			ImGui::SameLine();

			if (ImGui::Button("终止事件"))
			{
				FiberPool::Push([] {
					if (GSBDRandomEvents->EventData[selectedEvent].State == eRandomEventState::AVAILABLE)
					{
						GSBDRandomEvents->EventData[selectedEvent].State = eRandomEventState::CLEANUP;
					}
					else if (GSBDRandomEvents->EventData[selectedEvent].State == eRandomEventState::ACTIVE)
					{
						KillActiveEvent();
					}
					else
					{
						Notifications::Show("随机事件", "事件未处于激活状态。", NotificationType::Error);
					}
				});
			}

			ImGui::SameLine();

			if (ImGui::Button("传送到事件"))
			{
				FiberPool::Push([] {
					if (GSBDRandomEvents->EventData[selectedEvent].State >= eRandomEventState::AVAILABLE)
					{
						if (auto coords = GSBDRandomEvents->EventData[selectedEvent].TriggerPosition)
						{
							Self::GetPed().TeleportTo(coords);
						}
						else // Either update event coords TSE not sent yet or event doesn't register a trigger point
						{
							Notifications::Show("随机事件", "传送到事件失败：坐标无效。", NotificationType::Error);
						}
					}
					else
					{
						Notifications::Show("随机事件", "事件未处于激活状态。", NotificationType::Error);
					}
				});
			}

			if (GSBDRandomEvents->EventData[selectedEvent].State == eRandomEventState::ACTIVE)
			{
				if (auto eventThread = Scripts::FindScriptThread(randomEventScripts[static_cast<int>(selectedEvent)]))
				{
					if (auto netComponent = reinterpret_cast<GtaThread*>(eventThread)->m_NetComponent)
					{
						if (auto host = netComponent->GetHost())
						{
							ImGui::Text("主机：%s", host->GetName());
						}
						ImGui::SameLine();
						ImGui::BeginDisabled(netComponent->IsLocalPlayerHost());
						if (ImGui::SmallButton("取得控制权"))
						{
							FiberPool::Push([eventThread] {
								Scripts::ForceScriptHost(eventThread);
							});
						}
						ImGui::EndDisabled();
					}
				}
			}

			ImGui::Text("状态：%s", GetEventStateString().c_str());
			if (GSBDRandomEvents->EventData[selectedEvent].State == eRandomEventState::INACTIVE)
			{
				ImGui::Text("地点：无");
				ImGui::Text("触发范围：无");
			}
			else
			{
				ImGui::Text("地点：%d", GSBDRandomEvents->EventData[selectedEvent].Subvariation);
				ImGui::Text("触发范围：%.2f", GSBDRandomEvents->EventData[selectedEvent].TriggerRange); // Default value is 400, it will be updated once the event switches to the available state
			}

			// We should probably put this into a separate group, but I just don't want to do the same safety checks before rendering it
			ImGui::SeparatorText("冷却与可用时间");

			ImGui::InputInt("##cooldown", &setCooldown);
			ImGui::SameLine();
			if (ImGui::Button("设置冷却"))
			{
				int value = applyInMinutes ? (setCooldown * 60000) : setCooldown;
				FMRandomEvents->EventData[selectedEvent].InactiveTime = value;
			}
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip("需要成为自由模式脚本主机。");

			ImGui::InputInt("##availability", &setAvailability);
			ImGui::SameLine();
			if (ImGui::Button("设置可用时间"))
			{
				int value = applyInMinutes ? (setAvailability * 60000) : setAvailability;
				FMRandomEvents->EventData[selectedEvent].AvailableTime = value;
			}
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip("需要成为自由模式脚本主机。");

			ImGui::Checkbox("按分钟计算", &applyInMinutes);
		}));

		return menu;
	}
}