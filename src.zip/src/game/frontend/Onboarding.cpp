#include "Onboarding.hpp"
#include "GUI.hpp"
#include "core/commands/Commands.hpp"
#include "core/commands/BoolCommand.hpp"
#include "game/backend/AnticheatBypass.hpp"
#include "game/pointers/Pointers.hpp"
#include <shellapi.h>

namespace YimMenu
{
	static BoolCommand _OnboardingComplete{"$onboardingcomplete", "", ""};

	void ProcessOnboarding()
	{
		if (_OnboardingComplete.GetState())
			return;

		static bool ensure_popup_open = [] {
			ImGui::OpenPopup("重要！请务必阅读！");
			GUI::SetOnboarding(true);
			return true;
		}();

		const auto window_size = ImVec2{700, 500};
		const auto window_position = ImVec2{(*Pointers.ScreenResX - window_size.x) / 2, (*Pointers.ScreenResY - window_size.y) / 2};

		ImGui::SetNextWindowSize(window_size, ImGuiCond_Once);
		ImGui::SetNextWindowPos(window_position, ImGuiCond_Once);

		if (ImGui::BeginPopupModal("重要！请务必阅读！", nullptr, ImGuiWindowFlags_NoSavedSettings))
		{
			ImGui::TextWrapped("%s",
			    "欢迎使用 YimMenuV2！按 INSERT 或 Ctrl+\\ 即可打开菜单。随着 BattlEye 的引入，加入并留在公开战局的能力已严重受限。"
			    "你可以选择：只与其他 YimMenu 用户一起玩，或者连接到普通的 BattlEye 保护战局。"
			    "在普通战局中你会在三分钟内被自动踢出，而且即使重新开启 BattlEye，也可能被临时列入黑名单，最长两天无法加入");
			static int value = 0;
			ImGui::RadioButton("仅与 YimMenu 用户一起玩", &value, 0);
			ImGui::SameLine();
			ImGui::RadioButton("与所有玩家一起玩（已失效！）", &value, 1);
			ImGui::TextWrapped("%s",
			    "你随时可以在 网络 > 伪造 > 仅匹配 YimMenu 战局 里更改这一选择。我们的官方仓库位于 https://github.com/YimMenu/YimMenuV2。请务必只从 GitHub 下载本菜单，以免中招恶意软件。"
			    "你可以用该仓库反馈 Bug、提出功能建议，或通过 Pull Request 参与贡献。我们还开了一个 Matrix 服务器：https://matrix.to/#/#yimmenu:matrix.org，可更快地与开发者和其它用户交流。Matrix 是 Discord 的免费开源替代品，注册账号安全又方便");
			if (ImGui::Button("打开 GitHub"))
			{
				ShellExecuteA(NULL, "open", "https://github.com/YimMenu/YimMenuV2", NULL, NULL, SW_SHOWNORMAL);
			}
			ImGui::SameLine();
			if (ImGui::Button("打开 Matrix 服务器"))
			{
				ShellExecuteA(NULL, "open", "https://matrix.to/#/#yimmenu:matrix.org", NULL, NULL, SW_SHOWNORMAL);
			}
			ImGui::TextWrapped("%s",
			    "请经常检查更新，我们每晚都会发布新版本。但最重要的是：随便折腾，玩得开心！");
			if (ImGui::Button("关闭"))
			{
				Commands::GetCommand<BoolCommand>("cheaterpool"_J)->SetState(!value);
				_OnboardingComplete.SetState(true);
				GUI::SetOnboarding(false);
				ImGui::CloseCurrentPopup();
			}
			ImGui::EndPopup();
		}
	}
}