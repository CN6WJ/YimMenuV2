#include "core/commands/Command.hpp"
#include "core/commands/FloatCommand.hpp"
#include "game/backend/Self.hpp"
#include "game/gta/Natives.hpp"

namespace YimMenu::Features
{
	static FloatCommand _DirectionalTpDistance{"directionaltpdistance", "传送距离", "方向传送的距离"};

	class TpForward : public Command
	{
		using Command::Command;

		virtual void OnCall() override
		{
			auto ped = Self::GetPed();
			ped.TeleportTo(ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(ped.GetHandle(), 0, _DirectionalTpDistance.GetState(), 0));
		}
	};

	class TpBackward : public Command
	{
		using Command::Command;

		virtual void OnCall() override
		{
			auto ped = Self::GetPed();
			ped.TeleportTo(ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(ped.GetHandle(), 0, -_DirectionalTpDistance.GetState(), 0));
		}
	};

	class TpRight : public Command
	{
		using Command::Command;

		virtual void OnCall() override
		{
			auto ped = Self::GetPed();
			ped.TeleportTo(ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(ped.GetHandle(), _DirectionalTpDistance.GetState(), 0, 0));
		}
	};

	class TpLeft : public Command
	{
		using Command::Command;

		virtual void OnCall() override
		{
			auto ped = Self::GetPed();
			ped.TeleportTo(ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(ped.GetHandle(), -_DirectionalTpDistance.GetState(), 0, 0));
		}
	};

	class TpUp : public Command
	{
		using Command::Command;

		virtual void OnCall() override
		{
			auto ped = Self::GetPed();
			ped.TeleportTo(ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(ped.GetHandle(), 0, 0, _DirectionalTpDistance.GetState()));
		}
	};

	class TpDown : public Command
	{
		using Command::Command;

		virtual void OnCall() override
		{
			auto ped = Self::GetPed();
			ped.TeleportTo(ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(ped.GetHandle(), 0, 0, -_DirectionalTpDistance.GetState()));
		}
	};

	static TpForward  _DirectionalTpForward {"directionaltpforward",  "向前传送",  "把你向前传送"     };
	static TpBackward _DirectionalTpBackward{"directionaltpbackward", "向后传送", "把你向后传送"    };
	static TpRight    _DirectionalTpRight   {"directionaltpright",    "向右传送",    "把你向右传送"};
	static TpLeft     _DirectionalTpLeft    {"directionaltpleft",     "向左传送",     "把你向左传送" };
	static TpUp       _DirectionalTpUp      {"directionaltpup",       "向上传送",       "把你向上传送"          };
	static TpDown     _DirectionalTpDown    {"directionaltpdown",     "向下传送",     "把你向下传送"        };
}
