#include "core/commands/Command.hpp"
#include "core/commands/BoolCommand.hpp"
#include "core/commands/ListCommand.hpp"
#include "game/gta/Stats.hpp"
#include "game/gta/ScriptGlobal.hpp"
#include "game/gta/ScriptLocal.hpp"
#include "game/gta/Scripts.hpp"
#include "core/backend/ScriptMgr.hpp"
#include "game/gta/Natives.hpp"
#include "game/backend/Self.hpp"

namespace YimMenu::Features
{
	namespace KortzCenterHeist
	{
		// --- Primary Target ---
		static std::vector<std::pair<int, const char*>> kortzCenterTargets = {
		    {0, "最后的放纵"},
		    {1, "兔子的独白"},
		    {2, "罗马的陨落"},
		    {3, "兄弟啊兄弟"},
		    {4, "群像"},
		    {5, "凋零"},
		    {6, "真爱"},
		    {7, "窒息"},
		    {8, "消耗殆尽"},
		    {9, "我听见声音"},
		    {10, "无名之地的冬天"},
		    {11, "戴珍珠项链的少女"},
		    {12, "果上之猫"},
		    {13, "南瓜"},
		    {14, "双生无别"},
		    {15, "堆叠研究之五"},
		    {16, "我，水果"},
		    {17, "绕弯子"},
		    {18, "成功的过剩"},
		    {19, "榨干"},
		    {20, "蜿蜒归途"},
		    {21, "泰克犬"},
		    {22, "信任"},
		    {23, "至死不渝"},
		    {24, "什么瓜？"},
		    {25, "结果之努力"},
		    {26, "混战"}
		};
		static ListCommand _KortzCenterPrimaryTarget{"kortzcenterheistprimarytarget", "主要目标", "主要目标", kortzCenterTargets, 0};

		// --- General Purchases (MPX_K26_GENERAL_BS bits 5-8) ---
		static BoolCommand _KortzCenterGuardRoutes{"kortzcenterheistguardroutes", "守卫路线", "已购买守卫路线", true};
		static BoolCommand _KortzCenterGlassCutter{"kortzcenterheistglasscutter", "玻璃切割器", "已购买玻璃切割器", true};
		static BoolCommand _KortzCenterPowerDrills{"kortzcenterheistpowerdrills", "电钻", "已购买电钻", true};
		static BoolCommand _KortzCenterEMPCharges{"kortzcenterheistempcharges", "EMP 炸药", "已购买 EMP 炸药", true};

		// --- Prep Work Items ---
		static BoolCommand _KortzCenterScopeOut{"kortzcenterheistscopeout", "踩点侦查", "对科兹中心踩点", true};
		static BoolCommand _KortzCenterAlphaMail{"kortzcenterheistalphamail", "阿尔法邮件伪装", "阿尔法邮件伪装", true};
		static BoolCommand _KortzCenterHazmat{"kortzcenterheisthazmat", "防化服", "防化服", true};
		static BoolCommand _KortzCenterStaffKeycard{"kortzcenterheiststaffkeycard", "员工门禁卡", "员工门禁卡", true};
		static BoolCommand _KortzCenterTacticalEquip{"kortzcenterheisttacticalequip", "战术装备", "战术装备", true};
		static BoolCommand _KortzCenterHackingDevice{"kortzcenterheisthackingdevice", "黑客设备", "黑客设备", true};
		static BoolCommand _KortzCenterAccessCode{"kortzcenterheistaccesscode", "门禁密码", "门禁密码", true};
		static BoolCommand _KortzCenterUnmarkedWeapons{"kortzcenterheistunmarkedweapons", "无标识武器", "无标识武器", true};
		static BoolCommand _KortzCenterCaracara{"kortzcenterheistcaracara", "装甲食蚁兽", "装甲食蚁兽", true};
		static BoolCommand _KortzCenterAnnihilator{"kortzcenterheistannihilator", "隐形歼灭者", "隐形歼灭者", true};
		static BoolCommand _KortzCenterManchez{"kortzcenterheistmanchez", "曼切兹摩托", "曼切兹摩托", true};
		static BoolCommand _KortzCenterPrepEMP{"kortzcenterheistprepemp", "EMP 炸药（准备）", "EMP 炸药准备任务", true};
		static BoolCommand _KortzCenterGuardShipments{"kortzcenterheistguardshipments", "守卫货物", "守卫货物", true};
		static BoolCommand _KortzCenterGuardRoutesPrep{"kortzcenterheistguardroutesprep", "守卫路线（准备）", "守卫路线准备任务", true};
		static BoolCommand _KortzCenterGlassCutterPrep{"kortzcenterheistglasscutterprep", "玻璃切割器（准备）", "玻璃切割器准备任务", true};
		static BoolCommand _KortzCenterPowerDrillsPrep{"kortzcenterheistpowerdrillsprep", "电钻（准备）", "电钻准备任务", true};
		static BoolCommand _KortzCenterEMPChargesPrep{"kortzcenterheistempchargesprep", "EMP 炸药（准备）", "EMP 炸药准备任务", true};
		static BoolCommand _KortzCenterCaracaraPrep{"kortzcenterheistcaracaraprep", "食蚁兽（准备）", "装甲食蚁兽准备任务", true};
		static BoolCommand _KortzCenterAnnihilatorPrep{"kortzcenterheistannihilatorprep", "歼灭者（准备）", "隐形歼灭者准备任务", true};
		static BoolCommand _KortzCenterManchezPrep{"kortzcenterheistmanchezprep", "曼切兹（准备）", "曼切兹摩托准备任务", true};

		// --- Scoping ---
		static BoolCommand _KortzCenterScopeSecondary{"kortzcenterheistscopesecondary", "次要目标", "侦查次要目标", true};
		static BoolCommand _KortzCenterScopePOI{"kortzcenterheistscopepoi", "兴趣点", "侦查兴趣点", true};

		// --- In-Heist Shortcuts ---
		class SkipFingerprint : public Command
		{
			using Command::Command;

			virtual void OnCall() override
			{
				if (auto thread = Scripts::FindScriptThread("fm_mission_controller_v3"_J))
					*ScriptLocal(thread, 26866).As<int*>() = 5;
			}
		};

		class SkipSignalNodes : public Command
		{
			using Command::Command;

			virtual void OnCall() override
			{
				if (auto thread = Scripts::FindScriptThread("fm_mission_controller_v3"_J))
					*ScriptLocal(thread, 27914).As<int*>() = 5;
			}
		};

		class SkipDataCrack : public Command
		{
			using Command::Command;

			virtual void OnCall() override
			{
				if (auto thread = Scripts::FindScriptThread("fm_mission_controller_v3"_J))
				{
					for (int i = 0; i <= 7; i++)
						*ScriptLocal(thread, 1388).At(i, 4).As<int*>() = 1;
				}
			}
		};

		class CutGlass : public Command
		{
			using Command::Command;

			virtual void OnCall() override
			{
				if (auto thread = Scripts::FindScriptThread("fm_mission_controller_v3"_J))
					*ScriptLocal(thread, 32855).At(4, 13).At(3).As<float*>() = 100.0f;
			}
		};

		class DisableLaserGrid : public Command
		{
			using Command::Command;

			virtual void OnCall() override
			{
				if (auto thread = Scripts::FindScriptThread("fm_mission_controller_v3"_J))
				{
					*ScriptLocal(thread, 70416).As<int*>() = 4294784;
					*ScriptGlobal(1935711).As<int*>() |= 1;
				}
			}
		};

		class TakePrimaryTarget : public Command
		{
			using Command::Command;

			virtual void OnCall() override
			{
				if (auto thread = Scripts::FindScriptThread("fm_mission_controller_v3"_J))
					*ScriptLocal(thread, 29355).At(11).As<int*>() = 10;
			}
		};

		class TakeSecondaryTarget : public Command
		{
			using Command::Command;

			virtual void OnCall() override
			{
				if (auto thread = Scripts::FindScriptThread("fm_mission_controller_v3"_J))
					*ScriptLocal(thread, 29355).At(11).As<int*>() = 3;
			}
		};

		class AutoEnterPcAccessCode : public Command
		{
			using Command::Command;

			virtual void OnCall() override
			{
				if (auto thread = Scripts::FindScriptThread("fm_mission_controller_v3"_J))
				{
					for (int i = 0; i <= 2; i++)
					{
						*ScriptLocal(thread, 32818).At(1).At(i, 2).At(1).As<int*>() = 0;
						ScriptMgr::Yield(100ms);
						PAD::SET_CONTROL_VALUE_NEXT_FRAME(0, 237, 1.0);
					}
				}
			}
		};

		// --- Setup ---
		class Setup : public Command
		{
			using Command::Command;

			virtual void OnCall() override
			{
				int generalBits = -1;
				if (!_KortzCenterGuardRoutes.GetState()) generalBits &= ~(1 << 5);
				if (!_KortzCenterGlassCutter.GetState()) generalBits &= ~(1 << 6);
				if (!_KortzCenterPowerDrills.GetState()) generalBits &= ~(1 << 7);
				if (!_KortzCenterEMPCharges.GetState()) generalBits &= ~(1 << 8);

				int robberyProg = -1;
				if (!_KortzCenterScopeOut.GetState()) robberyProg &= ~(1 << 0);
				if (!_KortzCenterAlphaMail.GetState()) robberyProg &= ~(1 << 1);
				if (!_KortzCenterHazmat.GetState()) robberyProg &= ~(1 << 2);
				if (!_KortzCenterStaffKeycard.GetState()) robberyProg &= ~(1 << 3);
				if (!_KortzCenterTacticalEquip.GetState()) robberyProg &= ~(1 << 4);
				if (!_KortzCenterHackingDevice.GetState()) robberyProg &= ~(1 << 5);
				if (!_KortzCenterAccessCode.GetState()) robberyProg &= ~(1 << 6);
				if (!_KortzCenterUnmarkedWeapons.GetState()) robberyProg &= ~(1 << 7);
				if (!_KortzCenterCaracara.GetState()) robberyProg &= ~(1 << 8);
				if (!_KortzCenterAnnihilator.GetState()) robberyProg &= ~(1 << 9);
				if (!_KortzCenterManchez.GetState()) robberyProg &= ~(1 << 10);
				if (!_KortzCenterPrepEMP.GetState()) robberyProg &= ~(1 << 11);
				if (!_KortzCenterGuardShipments.GetState()) robberyProg &= ~(1 << 12);
				if (!_KortzCenterGuardRoutesPrep.GetState()) robberyProg &= ~(1 << 13);
				if (!_KortzCenterGlassCutterPrep.GetState()) robberyProg &= ~(1 << 14);
				if (!_KortzCenterPowerDrillsPrep.GetState()) robberyProg &= ~(1 << 15);

				int scopingBS = _KortzCenterScopeSecondary.GetState() ? -1 : 0;
				int poiBS = _KortzCenterScopePOI.GetState() ? -1 : 0;
				int caracaraPrepBS = _KortzCenterCaracaraPrep.GetState() ? -1 : 0;
				int annihilatorPrepBS = _KortzCenterAnnihilatorPrep.GetState() ? -1 : 0;
				int manchezPrepBS = _KortzCenterManchezPrep.GetState() ? -1 : 0;
				int empChargesPrepBS = _KortzCenterEMPChargesPrep.GetState() ? -1 : 0;

				Stats::SetInt("MPX_K26_GENERAL_BS", generalBits);
				Stats::SetInt("MPX_K26_GENERAL_BS2", -1);
				Stats::SetInt("MPX_K26_ROBBERY_PROG", robberyProg);
				Stats::SetInt("MPX_K26_SCOPING_BS", scopingBS);
				Stats::SetInt("MPX_K26_POI_BS", poiBS);
				Stats::SetInt("MPX_K26_HEIST_TARGET", _KortzCenterPrimaryTarget.GetState());
			}
		};

		static SkipFingerprint _KortzCenterSkipFingerprint{"kortzcenterheistskipfingerprint", "跳过指纹破解", "跳过机房里的指纹破解小游戏"};
		static SkipSignalNodes _KortzCenterSkipSignalNodes{"kortzcenterheistskipsignalnodes", "跳过节信号破解", "跳过金库键盘的信标节点破解"};
		static SkipDataCrack _KortzCenterSkipDataCrack{"kortzcenterheistskipdatacrack", "跳过数据破解", "跳过数据破解小游戏"};
		static CutGlass _KortzCenterCutGlass{"kortzcenterheistcutglass", "切割玻璃", "瞬间切开展示柜玻璃"};
		static DisableLaserGrid _KortzCenterDisableLaser{"kortzcenterheistdisablelaser", "关闭激光网", "关闭激光安防网"};
		static TakePrimaryTarget _KortzCenterTakePrimary{"kortzcenterheisttakeprimary", "拿取主要目标", "拿取主要目标画作（站在附近）"};
		static TakeSecondaryTarget _KortzCenterTakeSecondary{"kortzcenterheisttakesecondary", "拿取次要战利品", "拿取次要战利品（站在附近）"};
		static Setup _KortzCenterSetup{"kortzcenterheistsetup", "准备抢劫", "设置科兹中心抢劫"};
		static AutoEnterPcAccessCode _KortzCenterAutoEnterPcAccessCode{"kortzcenterheistautoenterpcaccesscode", "自动输入电脑密码", "自动输入电脑门禁密码"};
	}
}
